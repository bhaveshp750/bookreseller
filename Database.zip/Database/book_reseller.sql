-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2020 at 12:29 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_reseller`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `username` varchar(15) DEFAULT NULL,
  `passcode` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `passcode`) VALUES
(1, 'bhavesh', 'dadashri');

-- --------------------------------------------------------

--
-- Table structure for table `book_details`
--

CREATE TABLE `book_details` (
  `id` int(11) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_author` varchar(100) DEFAULT NULL,
  `book_category` varchar(25) DEFAULT NULL,
  `book_language` varchar(15) DEFAULT NULL,
  `book_condition` varchar(15) DEFAULT NULL,
  `book_purchase_date` varchar(15) DEFAULT NULL,
  `book_price` float DEFAULT NULL,
  `book_image` varchar(99) DEFAULT NULL,
  `book_description` text DEFAULT NULL,
  `username` varchar(35) DEFAULT NULL,
  `stock` varchar(9) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_details`
--

INSERT INTO `book_details` (`id`, `book_name`, `book_author`, `book_category`, `book_language`, `book_condition`, `book_purchase_date`, `book_price`, `book_image`, `book_description`, `username`, `stock`, `timestamp`) VALUES
(1001, 'The Hand Maids Tale', 'Margaret Atwood', 'Fiction', 'English', 'Good', '2011-02-28', 580, 'upload/The_handmaids_tale_20200606183737.jpg', 'It is set in a near-future New England, in a totalitarian state, known as Gilead, that has overthrown the United States government.', 'bhavesh@mail.com', 'Available', '2020-06-06 13:07:37'),
(1002, 'Don Quixote', 'Miguel De Cervantes', 'Noval', 'Spanish', 'Good', '2003-01-30', 800, 'upload/Don_Quijote_20200606183950.jpg', 'The plot revolves around the adventures of a noble (hidalgo) from La Mancha named Alonso Quixano, who reads so many chivalric romances that he loses his mind and decides to become a knight-errant.', 'bhavesh@mail.com', 'Sold', '2020-06-06 13:09:50'),
(1003, 'Ulysses', 'James Joyce', 'Noval', 'English', 'Good', '2005-01-12', 600, 'upload/Ulysses_James_Joyce_20200606184102.jpg', 'Ulysses chronicles the appointments and encounters of Leopold Bloom in Dublin in the course of an ordinary day, 16 June 1904.', 'bhavesh@mail.com', 'Available', '2020-06-06 13:11:02'),
(1004, 'War And Peace', 'Leo Tolstoy', 'Noval', 'Russain', 'Fair', '2002-06-03', 799, 'upload/War_and_peace_20200606191737.jpg', 'The novel chronicles the French invasion of Russia and the impact of the Napoleonic era on Tsarist society through the stories of five Russian aristocratic families.', 'chandu@mail.com', 'Sold', '2020-06-06 13:45:11'),
(1005, 'Hamlet', 'William Shakespeare', 'Drama', 'English', 'Good', '2006-02-18', 599, 'upload/hamlet_20200606192016.jpg', 'Hamlet is considered among the most powerful and influential works of world literature, with a story capable of \"seemingly endless retelling and adaptation by others\".', 'chandu@mail.com', 'Available', '2020-06-06 13:50:16'),
(1006, 'Invisible Man', 'Ralph Ellison', 'Noval', 'English', 'Fair', '2009-08-05', 399, 'upload/Invisible_Man_20200606192206.jpg', 'Invisible Man won the U.S. National Book Award for Fiction in 1953.', 'chandu@mail.com', 'Sold', '2020-06-06 13:52:06'),
(1007, 'Home Going', 'Yaa Gyasi', 'Fiction', 'English', 'Good', '2012-03-15', 599, 'upload/Home_going_20200606192410.jpg', 'Each chapter in the novel follows a different descendant of an Asante woman named Maame, starting with her two daughters, who are half sisters, separated by circumstance.', 'chandu@mail.com', 'Available', '2020-06-06 13:54:10'),
(1008, 'History of Modern India', 'Bipan Chandra', 'History', 'English', 'Good', '2015-09-12', 249, 'upload/History_of_modern_India_20200606192856.jpg', 'History of Modern India presents an authoritative overview of the history of what was known as British India. The text is largely based on the author s research on nationalism and colonialism in India and also draws from the works of eminent historians of the period.', 'mananp@mail.com', 'Available', '2020-06-06 13:58:56'),
(1009, 'Three Thousand Stitches', 'Sudha Murthy', 'Story', 'English', 'Good', '2019-07-14', 699, 'upload/Three_thousand_stitches_20200606193230.jpg', 'Three thousand stitches is a story where the author wanted to eradicate devadasi system and for this, she tried hard.', 'mananp@mail.com', 'Available', '2020-06-06 14:02:30'),
(1010, 'Marketing Management', 'Kotler and Keller', 'Maths', 'English', 'Good', '2018-05-04', 200, 'upload/Marketing_management_20200606193420.jpg', 'The best book for marketing management that I have found is the 15th edition of Marketing Management by Kotler Keller.', 'mananp@mail.com', 'Available', '2020-06-06 14:04:20'),
(1011, 'Food in England', 'Dorothy Harthey', 'History', 'English', 'Fair', '2004-02-15', 499, 'upload/Food_for_england_20200606193627.jpg', 'The book provides what has been called on idiosyncratic and a combative take on the history of English cooking.', 'mananp@mail.com', 'Sold', '2020-06-06 14:06:27');

-- --------------------------------------------------------

--
-- Table structure for table `login_table`
--

CREATE TABLE `login_table` (
  `user_id` int(11) NOT NULL,
  `username` varchar(35) DEFAULT NULL,
  `_password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_table`
--

INSERT INTO `login_table` (`user_id`, `username`, `_password`) VALUES
(1, 'admin', '$2y$10$Wk5kWqccsNBEzT4.w6/XReRltdHbqAE5VfrT.vzKeIawFOkfLqG4.'),
(2, 'chandu@mail.com', '$2y$10$.182v96iXVxrCi7tGDp.ruXNqOt5b7AIJ1mDyKupEbx6OZkNK3iza'),
(3, 'mananp@mail.com', '$2y$10$W0b00WosTMU7HRC04HRecuedTMEeciHAnelMlxabcea6VE7YnLjIS'),
(4, 'hardik@mail.com', '$2y$10$4S0DjK1G9slP9GGxNd.lk.Qrdc.PpOH5SvwOCHD4nRKkTFi2Ync8K'),
(5, 'dhp@mail.com', '$2y$10$0qEP3HlwXPlzm6d9dlpBhuQ9.rGdvme.khlhI5tGe4I.bUTAnh7LG'),
(6, 'bhavesh@mail.com', '$2y$10$o8afohVpjf875B.o0Y9aDu7HcH8JdGNBbAfRruCI6JGstOO77drL2'),
(7, 'jugalpatel@mail.com', '$2y$10$z9RfAiU2Cw8IL7veTBuL8.EY30T.0fSR3RqpxLwC24edciBeNrHoe'),
(8, 'sonal@mail.com', '$2y$10$m1ejJJgTA3zQJ2NkLPgJCuG9luuFnJZEr32Mj7I8XnT.Vp2agWdCe');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `products_name` varchar(255) NOT NULL,
  `buyer_username` varchar(35) DEFAULT NULL,
  `billing_name` varchar(35) DEFAULT NULL,
  `billing_email` varchar(35) DEFAULT NULL,
  `billing_phone` bigint(10) DEFAULT NULL,
  `billing_house` varchar(255) DEFAULT NULL,
  `billing_area` varchar(35) NOT NULL,
  `billing_landmark` varchar(35) NOT NULL,
  `billing_city` varchar(35) NOT NULL,
  `billing_pincode` int(6) NOT NULL,
  `total_amount` decimal(6,2) DEFAULT NULL,
  `pmode` varchar(35) DEFAULT NULL,
  `order_status` varchar(255) NOT NULL,
  `timestamp` varchar(25) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `products_name`, `buyer_username`, `billing_name`, `billing_email`, `billing_phone`, `billing_house`, `billing_area`, `billing_landmark`, `billing_city`, `billing_pincode`, `total_amount`, `pmode`, `order_status`, `timestamp`) VALUES
(1025, 'War And Peace, Food in England', 'bhavesh@mail.com', 'Bhavesh Patel', 'bhaveshp750@gmail.com', 9867512334, 'Plot no- B9', 'nagar', 'Near Temple', 'Hubli', 580031, '1298.00', 'Net Banking', 'Order Placed', '2020-12-25 09:12:23'),
(1026, 'Don Quixote, Invisible Man', 'mananp@mail.com', 'Manan Patel', 'mananp@mail.com', 8877997788, 'Durga', 'New area', 'Cross', 'Hubli', 580031, '1199.00', 'Cash on Delivery', 'Order Placed', '2020-12-26 00:00:53');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `book_seller` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `book_id`, `book_seller`) VALUES
(116, 1025, 1011, 'chandu@mail.com'),
(117, 1025, 1004, 'mananp@mail.com'),
(118, 1026, 1002, 'bhavesh@mail.com'),
(119, 1026, 1006, 'chandu@mail.com');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `lname` varchar(20) DEFAULT NULL,
  `mobile` bigint(10) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `passcode` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fname`, `lname`, `mobile`, `username`, `passcode`, `timestamp`) VALUES
(1, 'Chandulal', 'Patel', 9877899877, 'chandu@mail.com', '$2y$10$.182v96iXVxrCi7tGDp.ruXNqOt5b7AIJ1mDyKupEbx6OZkNK3iza', '2020-05-23 14:19:55'),
(2, 'Manan', 'Patel', 8811322166, 'mananp@mail.com', 'manan123', '2020-05-28 12:38:21'),
(3, 'Hardik', 'patel', 9988774411, 'hardik@mail.com', 'hardik123', '2020-05-29 10:21:17'),
(4, 'Dhanasukhlal', 'Patel', 9988775566, 'dhp@mail.com', 'dhp123', '2020-05-31 10:49:56'),
(5, 'Bhavesh', 'Patel', 9988774411, 'bhavesh@mail.com', '$2y$10$o8afohVpjf875B.o0Y9aDu7HcH8JdGNBbAfRruCI6JGstOO77drL2', '2020-06-03 11:26:19'),
(6, 'Jugal', 'Chouhan', 7894567894, 'jugalpatel@mail.com', '$2y$10$z9RfAiU2Cw8IL7veTBuL8.EY30T.0fSR3RqpxLwC24edciBeNrHoe', '2020-06-13 17:46:24'),
(7, 'Sonal', 'Patel', 99977884455, 'sonal@mail.com', '$2y$10$m1ejJJgTA3zQJ2NkLPgJCuG9luuFnJZEr32Mj7I8XnT.Vp2agWdCe', '2020-12-09 08:19:10');

--
-- Triggers `register`
--
DELIMITER $$
CREATE TRIGGER `update_login_tabe` AFTER INSERT ON `register` FOR EACH ROW BEGIN
INSERT INTO `login_table` (`username`, `_password`) VALUES ( new.username, new.passcode);
end
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_password` AFTER UPDATE ON `register` FOR EACH ROW BEGIN
UPDATE login_table SET `_password` = new.passcode where username=new.username;
end
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_details`
--
ALTER TABLE `book_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_table`
--
ALTER TABLE `login_table`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book_details`
--
ALTER TABLE `book_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1014;

--
-- AUTO_INCREMENT for table `login_table`
--
ALTER TABLE `login_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1027;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
